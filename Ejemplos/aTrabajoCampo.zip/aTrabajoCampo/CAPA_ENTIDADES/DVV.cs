﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CAPA_ENTIDADES
{
    public class DVV
    {
        public string TablaNombre { get; set; }
        public int ValorDVV { get; set; }
        public DateTime FechaActualizacion { get; set; }
    }
}
