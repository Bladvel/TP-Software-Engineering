﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CAPA_ENTIDADES
{
   public class EstadoPedido
   {
        public int IdEstadoPedido { get; set; }
        public string detalle { get; set; }
    }
}
